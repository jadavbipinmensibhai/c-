﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pyramid_for_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            for (i = 1; i <= 5; i++) 
            {
                for (i = 1; i <=i; j++) 
                Console.Write(j);
                Console.ReadLine();
            }
        }
    }
}
