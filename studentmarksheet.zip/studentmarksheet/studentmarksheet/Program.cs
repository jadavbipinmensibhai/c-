﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace studentmarksheet
{
    class stud
    {
        static void Main(string[] args)
        {
            int M1, M2, M3, M4, Total;
            float avg;
            Console.WriteLine("enter marks");
            M1= Convert.ToInt32(Console.ReadLine());
            M2= Convert.ToInt32(Console.ReadLine());
            M3= Convert.ToInt32(Console.ReadLine());
            M4= Convert.ToInt32(Console.ReadLine());
            Total =M1+M2+M3+M4;
            avg = Total/4;
            Console.WriteLine("pr:"+avg);
            if (avg >= 90)
                Console.WriteLine("A");
            else if (avg <= 90 && avg >= 70)
                Console.WriteLine("B");
            else if (avg <= 70 && avg >= 50)
                Console.WriteLine("C");
            else if (avg <= 50 && avg >= 30)
                Console.WriteLine("D");
            else
                Console.WriteLine("fail");
                Console.Read();
        }
    }
}
