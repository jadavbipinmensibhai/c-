﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Boxingunboxing.program
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = ;
            object obj = num;
            int i = (int)obj;

            Console.WriteLine("value of obj object is " + obj);
            Console.WriteLine("value of i is " + i);
        }
        
    }
}
