﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12345whileloop
{
    class program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
