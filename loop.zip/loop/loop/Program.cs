﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12345_for_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            for (i = 1; i<5; i++ )
            {
                Console.WriteLine("{0}",i);
            }
            Console.Write("\n\n",i);
            Console.ReadLine();

        }
    }
}
