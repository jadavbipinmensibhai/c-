﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace onedimentionarray
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = new string[5];
            int i;
            //1d array
            Console.WriteLine("enter name:");
            for (i = 0; i < 5; i++)
            {
                str[i] = Console.ReadLine();
                Console.WriteLine(str[i]);
            }
            Console.Read();

         }
    }
}
