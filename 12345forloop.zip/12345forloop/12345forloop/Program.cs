﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12345forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("1,2,3,4,5");
            for (i = 1; i <= 5; i++)
            {
                Console.Write(i);
            }
        }
    }
}
