﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12345do_whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i <= 5);
        }
    }
}
